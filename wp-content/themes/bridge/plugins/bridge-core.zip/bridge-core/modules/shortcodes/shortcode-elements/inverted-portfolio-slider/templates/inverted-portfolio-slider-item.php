<article class="qode-ips-item swiper-slide">
	<div class="qode-ips-item-inner">
        <div class="qode-ips-content-holder">
            <div class="qode-ips-image-holder">
                <?php echo bridge_core_get_shortcode_template_part( 'templates/post-info/image', 'inverted-portfolio-slider', '', $params ); ?>
            </div>
            <div class="qode-ips-title-holder">
                <?php echo bridge_core_get_shortcode_template_part( 'templates/post-info/title', 'inverted-portfolio-slider', '', $params ); ?>
            </div>
        </div>
        <div class="qode-ips-info-holder">
            <?php echo bridge_core_get_shortcode_template_part( 'templates/post-info/info', 'inverted-portfolio-slider', '', $params ); ?>
        </div>
    </div>
</article>