<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/gradient-icon-with-text/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/gradient-icon-with-text/gradient-icon-with-text.php';